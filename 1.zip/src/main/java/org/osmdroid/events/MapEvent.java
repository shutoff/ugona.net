package org.osmdroid.events;

/*
 * Tagging interface for map events
 *
 * @author Theodore Hong
 */
public interface MapEvent {

}
